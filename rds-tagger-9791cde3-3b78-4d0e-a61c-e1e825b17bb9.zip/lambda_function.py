import boto3

from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
    # TODO implement
    # -*- coding: utf-8 -*-
    """
    Created on Fri Jul 21 00:17:58 2017

    @author: dlim
    """
    awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    #awsAccounts = ['579292207088']
     
    for accountNumber in awsAccounts:
    
        
        availTagList = []
    
        try:
            
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::" + accountNumber + ":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )

            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
            # get all of the db instances
            rds = boto3.client('rds',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
            
            dbs = rds.describe_db_instances()
            
            # use ec2 to get regions
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
            
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            # print(regions)

            msgString = ''

            for region in regions:
            
                for db in dbs['DBInstances']:
                    print(db['DBInstanceIdentifier'])
                    print(db['DBInstanceStatus'])
        
                    if (db['DBInstanceStatus'] == 'available' or db['DBInstanceStatus'] == 'stopped'):
                        print("check if tag is available if not start adding tag template")
        
                        currentTagDict = rds.list_tags_for_resource(ResourceName=db['DBInstanceArn'])
                        currentTagList = currentTagDict.get("TagList")
        
                        tagDict = dict()
        
                        if currentTagList:
        
                            for tag in currentTagList:
                                tagDict[tag['Key']] = tag['Value']
        
                            if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') == 'none':
                                rds.add_tags_to_resource(ResourceName=db['DBInstanceArn'],  Tags=[{'Key': 'TTL Shutdown Time', 'Value': '18'}])
        
                            if tagDict.get('Region') and tagDict.get('Region') == 'none':
                                rds.add_tags_to_resource(ResourceName=db['DBInstanceArn'],Tags=[{'Key': 'Region', 'Value': 'sgdc'}])
        
                            availTagList = []
                            requiredTagList = ["Name", "Owner", "Purpose", "Region", "TTL Start Time", "TTL Shutdown Time","TTL Shutdown Date"]
        
                            for rds_tag in currentTagList:
                                tag_key = rds_tag['Key']
                                tag_value = rds_tag['Value']
        
                                availTagList.append(tag_key)
        
                            tagNeeds = list(set(requiredTagList) - set(availTagList))
        
                            for key in tagNeeds:
                                print("Tag Key : " + key)
                                value='none'
                                
                                if key == 'Region':
                                    value='sgdc'
                                
                                if key == 'TTL Shutdown Time':
                                    value='19'
        							
                                rds.add_tags_to_resource(ResourceName=db['DBInstanceArn'],Tags=[{'Key': key, 'Value': value}])
        						
                            # create tag resource starts here
                        else:
                            requiredTagList = ["Name", "Owner", "Purpose", "Region", "TTL Start Time", "TTL Shutdown Time","TTL Shutdown Date"]
        
                            for key in requiredTagList:
                                print("Tag Key : " + key)
                                
                                value='none'
                                
                                if key == 'Region':
                                    value='sgdc'
                                
                                if key == 'TTL Shutdown Time':
                                    value='19'

                                rds.add_tags_to_resource(ResourceName=db['DBInstanceArn'], Tags=[{'Key': key, 'Value': value}])
            
            print("Account :" + accountNumber + " - Region "+ region + " - Tag Operation completed")                        
            
        except ClientError as e:
            print(e)
    
    return 'RDS tag operation has been completed'
import boto3
import pprint
import os

#Build=""
region = "us-east-1"
ecs = boto3.client('ecs')

def lambda_handler(event, context):
    service_response_soc = ecs.update_service(
        cluster='OPERATIONS',
        service='SOC-NEXTLABS-COM',
        desiredCount=1,
        forceNewDeployment=True,
        taskDefinition=taskDefinitionRev_soc,
        deploymentConfiguration={
            'maximumPercent': 200,
            'minimumHealthyPercent': 100
        }
    )
    #print "service updated"
    print(service_response_soc)
    

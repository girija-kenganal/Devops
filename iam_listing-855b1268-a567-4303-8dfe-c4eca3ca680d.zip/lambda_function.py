def lambda_handler(event, context):
    import sys
    from datetime import datetime, timedelta
    import boto3
    import os
    import csv
    sts_client = boto3.client('sts')
    awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    for accountNumber in awsAccounts:
        assumedRoleObject = sts_client.assume_role(RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",RoleSessionName="AssumeRoleSession1")
        credentials = assumedRoleObject['Credentials']
    
        iam = boto3.client('iam',aws_access_key_id = credentials['AccessKeyId'],aws_secret_access_key = credentials['SecretAccessKey'],aws_session_token = credentials['SessionToken'])
        iamr = boto3.resource('iam',aws_access_key_id = credentials['AccessKeyId'],aws_secret_access_key = credentials['SecretAccessKey'],aws_session_token = credentials['SessionToken'])
        s3_bucket = 'iam-listings'
        todays_date = datetime.now().strftime ("%d-%m-%Y")
        s3_key_name = todays_date+'.csv'
        role_key = accountNumber+"-Role-"+s3_key_name
        users_key = accountNumber+"-User-"+s3_key_name
        # iam = boto3.client('iam')
        # iamr = boto3.resource('iam')
        user_headerallowed = []
        user_headerallowed.extend(["User Name","Attached Managed Policies", "Attached Inline Policies", "Access Type", "Attached Groups", "Attached group Policies" ])
        with open("/tmp/user-detailedscsv.csv",'w') as userresultFile:
            wr = csv.writer(userresultFile, dialect='excel')
            wr.writerows([user_headerallowed])
        for userlist in iam.list_users()['Users']:
            username = userlist['UserName']
            user_array=[]
            user_managed_policy_array=[]
            user_inline_policy_array=[]
            user_attached_group_array=[]
            group_attached_policy_array=[]
            user_array.append(username)
            #userGroups = iam.list_groups_for_user(UserName=userlist['UserName'])
            managed_user_policies =  iam.list_attached_user_policies(UserName=userlist['UserName'])
            inline_user_policies = iam.list_user_policies(UserName=userlist['UserName'])
            print("Username: "  + userlist['UserName'])
            print("Assigned Managed Policies: ")
            for policy in managed_user_policies['AttachedPolicies']:
                print(policy['PolicyName'])
                user_managed_policy_array.append(policy['PolicyName'])
            user_array.append(user_managed_policy_array)
            print("Assigned Inline Policies: ")
            for policy in inline_user_policies['PolicyNames']:
                if policy:
                    print(policy)
                    user_inline_policy_array.append(policy)
                else:
                    print("No Inline Policy Attached ")
            user_array.append(user_inline_policy_array)
            login_profile = iamr.LoginProfile(username)
            try:
                login_profile.create_date
                print("Access Type : Console Access")
                user_array.append("Console Access")
            except:
                print("Access Type : Programatic Access")
                user_array.append("Programatic Access")
            userGroups = iam.list_groups_for_user(UserName=username)
            print("Assigned groups: ")
            for groupName in userGroups['Groups']:
                group_name = groupName['GroupName']
                user_attached_group_array.append(group_name)
                print(groupName['GroupName'])
                group_policies = iam.list_attached_group_policies(GroupName=group_name)
                for policy in group_policies['AttachedPolicies']:
                    print(policy['PolicyName'])
                    group_attached_policy_array.append(policy['PolicyName'])
            user_array.append(user_attached_group_array)
            user_array.append(group_attached_policy_array)
            with open('/tmp/user-detailedscsv.csv', 'a') as usercsvFile:
                writer = csv.writer(usercsvFile)
                writer.writerow(user_array)
                usercsvFile.close()
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file('/tmp/user-detailedscsv.csv', s3_bucket, users_key) 
        print("----------------------------")
        print("-----------------------------Roles-------------------------------------")
        roles = iam.list_roles()
        Role_list = roles['Roles']
        role_headerallowed = []
        role_headerallowed.extend(["Role Name","Attached Policies" ])
        with open("/tmp/role-detailedscsv.csv",'w') as roleresultFile:
            wr = csv.writer(roleresultFile, dialect='excel')
            wr.writerows([role_headerallowed])
        for role in Role_list:
            role_array=[]
            role_policy_array=[]
            role_name = role['RoleName']
            role_array.append(role_name)
            role_policies = iam.list_attached_role_policies(RoleName=role_name)
            #print(role_policies)
            print("Role Name : " + role_name)
            print("Assigned Role Policies: ")
            for policy in role_policies['AttachedPolicies']:
                policy_name = policy['PolicyName']
                role_policy_array.append(policy_name)
                print(policy['PolicyName'])
            role_array.append(role_policy_array)
            with open('/tmp/role-detailedscsv.csv', 'a') as rolecsvFile:
                writer = csv.writer(rolecsvFile)
                writer.writerow(role_array)
                rolecsvFile.close()
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file('/tmp/role-detailedscsv.csv', s3_bucket, role_key) 
        print("----------------------------")

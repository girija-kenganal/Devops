import json
import boto3
import logging
#import requests
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

dynamodb = boto3.resource('dynamodb','us-east-1')

def create_presigned_url(bucket_name, object_name, expiration=3600):
    """Generate a presigned URL to share an S3 object

    :param bucket_name: string
    :param object_name: string
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Presigned URL as string. If error, returns None.
    """

    # Generate a presigned URL for the S3 object
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=expiration)
    except ClientError as e:
        print(str(e))
   
        return { 
                "statusCode": 500,
                "body": json.dumps("error"),

        
        }
    

    # The response contains the presigned URL
    return response

def lambda_handler(event, context):
    # TODO implement
    bucket = 'nxlwpweb'
    print(event)
    
    try:
        # "body": "Whitepaper - What will data-centric security look like over the next 5 years?\ncornelia.lechner@airbus.com\n|WP_Trends_in_Data_Security.pdf",
        whitePaper=event['body']
        print(whitePaper)
        whitePaperPdf=whitePaper.split("|")[1]
        requesterEmail=whitePaper.split("\n")[1]
        whitePaperTitle=whitePaper.split("\n")[0]

    except IndexError as e: 
        print( "Index out of range: %s" % e)
        return { 
                "statusCode": 200,
                "body": json.dumps("NOT A WHITEPAPER REQUEST, JUST IGNORE"),

        
        }
        quit()

    pdfExtension = ".pdf"
    
    if pdfExtension not in whitePaperPdf:
        print ("PDF Not Found!")
        return { 
                "statusCode": 200,
                "body": json.dumps("PDF NOT FOUND, NOT WHITEPAPER REQUEST"),

        
        }
        quit()
        
    else:
        print ("Not PDF")
        
    print(whitePaperTitle + " | " + requesterEmail + " | "+ whitePaperPdf)
    
    
    # query table for whitePaperPdf and requesterEmail attributes 
    table = dynamodb.Table("whitepaper")
    responseGet = table.query(
        KeyConditionExpression=
            Key('whitePaperPdf').eq(whitePaperPdf) & Key('requesterEmail').eq(requesterEmail)
    )
    print(responseGet)
    items = responseGet['Items']
    print(items)
    
    try:
    # If whitePaperPdf for requesterEmail doesn't exists then insert record into dynamodb and send email to requester
        if items == [] :
            # insert whitePaperPdf ,requesterEmail , whitePaperTitle in whitepaper into dynamodb table
            table.put_item(
                Item={
                    'whitePaperPdf': whitePaperPdf,
                    'requesterEmail': requesterEmail,
                    'whitePaperTitle': whitePaperTitle
                }
            )
            
            url = create_presigned_url(bucket,"whitepapers/"+whitePaperPdf)
            if url is not None:
                print(url);
        
                toEmail=requesterEmail
                #toEmail="david.lim@nextlabs.com"
                
                fromEmail ="no-reply@nextlabs.com"
                # Create message container - the correct MIME type is multipart/alternative.
                msg = MIMEMultipart('alternative')
                msg['Subject'] = "Nextlabs - "+ whitePaperTitle
                msg['From'] = fromEmail
                msg['To'] = toEmail
                
                # Create the body of the message (a plain-text and an HTML version).
               
                html = """
                    <html>
                        <head>
                      <style type="text/css">
                        .askForm {
                            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                            border-collapse: collapse;
                            width: 100%;
                        }
            
                        .askForm td, .askForm th {
                            border: 1px solid #ddd;
                            padding: 8px;
                        }
            
                        .askForm tr:nth-child(even){background-color: #f2f2f2;}
            
                        .askForm tr:hover {background-color: #ddd;}
            
                        .askForm th {
                            padding-top: 12px;
                            padding-bottom: 12px;
                            text-align: left;
                            background-color: #f16a25;
                            color: white;
                        }
                    </style>
                    </head>
                    <body>
                    
                    """
                
                html=html + '<p>'
                
                html=html + "Hi, <br><br> Thanks for your interest in our White Paper Download. Here’s the information you requested. You can access the White Paper by clicking the link below. <br><br><a href='"+url +"'>"+whitePaperTitle+"</a>."
                html=html + '</p>'
                
                html=html + '<p>'
                html=html + "We hope you read it soon. Because We are sure you’ll discover how data centric secutiry approach can enable you to make better decisions."
                html=html + '</p>'
                
                html=html + '<p>Thank You.</p>'
            
                html=html + """
                    </body>
                  </html>
                """
                
                part = MIMEText(html, 'html')
                try:
                    msg.attach(part)
                    server = smtplib.SMTP('smtp.office365.com', 587)
                    server.starttls()
        
                    server.login("no-reply@nextlabs.com", "tM2b)3HjuiomLsAw")
                    server.sendmail(fromEmail, toEmail, msg.as_string())
                    server.quit()
                    print("White paper has been successfully emailed")
                        
                    return { 
                            "statusCode": 200,
                            "body": json.dumps("success"),
        
                    
                    }
            
                except smtplib.SMTPException as e:
                    print(str(e))
               
                    return { 
                            "statusCode": 500,
                            "body": json.dumps("error"),
        
                    
                    }
            
    except ClientError as e:
        print("Here")
        print(e)
        return {"statusCode": 500,"body": json.dumps("error"),"isBase64Encoded":"false","headers": { "Access-Control-Allow-Origin" : "*", "Access-Control-Allow-Credentials" : "true" } }
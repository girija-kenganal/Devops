import boto3
from datetime import datetime
from pytz import timezone
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
        
   
    awsAccounts=['579292207088','025378961092']
    
    for accountNumber in awsAccounts:
        try:
            print(accountNumber)
            ec_client = boto3.client('ec2')
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )
            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
           
     
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
              
            
            
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            print(regions)
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2', region_name=region)
            
                snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                
                    
                
                    if instance_tags:
                
                        for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                
                        try:
                            Archive = tagDict.get('Archive')
                            print(Archive)
                            # dir(instance)

                            if 'sgdc' in tagDict.values():
                                tzone = timezone('Asia/Singapore')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                DayList = tagDict.get('Day')
                                DayFound = str(DayList).find(str(Weekday))
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                print(DayList)
                                print(DayFound)
                                

                                print("TTL Shutdown Time %s %s" % (tagDict.get('TTL Shutdown Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                
                                
                                if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') != 'none' and int(tagDict.get('TTL Shutdown Time')) == currTime and int(tagDict.get('TTL Shutdown Time')) != 24:
                                    clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                    print("Shutting down EC2 -  %s" % str(instance.id))
                                    msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))

                                if tagDict.get('Archive') == 'Disabled': 
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).terminate()
                                        print("Terminating EC2 instance -  %s" % str(instance.id))
                                        msgString=msgString+"Terminating EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                   
                                elif tagDict.get('Archive') == 'Enabled':
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                        print("Shutting down EC2 -  %s" % str(instance.id))
                                        msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                        print("Instance tag Archive value is enabled")
                                    
                                     
                            if 'smdc' in tagDict.values():
                                tzone = timezone('America/Los_Angeles')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                DayList = tagDict.get('Day')
                                DayFound = str(DayList).find(str(Weekday))
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                print(DayList)
                                print(DayFound)
                                
                                print("TTL Shutdown Time %s %s" % (tagDict.get('TTL Shutdown Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                
                               
                                if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') != 'none' and int(tagDict.get('TTL Shutdown Time')) == currTime and int(tagDict.get('TTL Shutdown Time')) != 24:
                                    clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                    print("Shutting down EC2 -  %s" % str(instance.id))
                                    msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                            
                                if Archive == 'Disabled': 
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).terminate()
                                        print("Terminating EC2 instance -  %s" % str(instance.id))
                                        msgString=msgString+"Terminating EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                   
                                elif Archive == 'Enabled':
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                        print("Shutting down EC2 -  %s" % str(instance.id))
                                        msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                        print("Instance tag Archive value is enabled")
                            
                            if 'cdc' in tagDict.values():
                                tzone = timezone('Asia/Singapore')
                                sa_time = datetime.now(tzone)
                                currTime = int(sa_time.strftime('%H'))
                                currDate = datetime.strptime(str(sa_time.date()), '%Y-%m-%d').date()
                                Weekday = currDate.weekday()
                                DayList = tagDict.get('Day')
                                DayFound = str(DayList).find(str(Weekday))
                                print(currDate)
                                print(Weekday)
                                print(tagDict.get('Name'))
                                print(DayList)
                                print(DayFound)
                                
                                print("TTL Shutdown Time %s %s" % (tagDict.get('TTL Shutdown Time'), sa_time.strftime('%a')))
                                print("Current Time -  %s" % str(sa_time))
                                
                            
                                if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') != 'none' and int(tagDict.get('TTL Shutdown Time')) == currTime and int(tagDict.get('TTL Shutdown Time')) != 24:
                                    clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                    print("Shutting down EC2 -  %s" % str(instance.id))
                                    
                                if Archive == 'Disabled': 
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).terminate()
                                        print("Terminating EC2 instance -  %s" % str(instance.id))
                                        msgString=msgString+"Terminating EC2 instance -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                   
                                elif Archive == 'Enabled':
                                    if tagDict.get('Project End Date') and tagDict.get('Project End Date') != 'none' and datetime.strptime(tagDict.get('Project End Date'), '%Y-%m-%d').date() < currDate:
                                        clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                        print("Shutting down EC2 -  %s" % str(instance.id))
                                        msgString=msgString+"Shutting down EC2 -  Region %s -  Instance Id - %s" % (region,str(instance.id))
                                        print("Instance tag Archive value is enabled")
                                    
                            '''Stop all instance without Tag value and if tag value is eq none'''
                            
                            if not tagDict.get('TTL Shutdown Time') or tagDict.get('TTL Shutdown Time') == 'none':
                                print("Stopping Instance - Reason: No TTL Shutdown Time Tag or  value found %s %s" % (region,str(instance.id)))
                                clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                print("Current Time -  %s" % str(sa_time))
                            if not tagDict.get('Owner') or tagDict.get('Owner') == 'none':
                                print("Stopping Instance - Reason: No Owner Tag or value found %s %s" % (region,str(instance.id)))
                                clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                print("Current Time -  %s" % str(sa_time))
                            
                            if not tagDict.get('Project End Date') or tagDict.get('Project End Date') == 'none':
                                print("Stopping Instance - Reason: No Project End Tag or value found %s %s" % (region,str(instance.id)))
                                clientEC2.instances.filter(InstanceIds=[instance.id]).stop()
                                print("Current Time -  %s" % str(sa_time))
                                
                        except ClientError as e:
                            print(e)
                            

            if not msgString=='':
                print(msgString)

            

                            
        except ClientError as e:
            print(e)         
                
    return "success"
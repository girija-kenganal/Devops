import json
import boto3
import urllib2
import pymongo
from datetime import datetime

def lambda_handler(event, context):
	ec2 = boto3.resource('ec2', 'us-east-1')
	connection = pymongo.MongoClient("mongodb://Ram:Ram.5353@ds151180.mlab.com:51180/ramk")
	db=connection.ramk
	record1 = db.book_collection1
	record1.drop()
	page = urllib2.urlopen("http://l4wisdom.com/pymongo/code/insert/test.json")
	parsed = json.loads(page.read())
	for item in parsed["Records"]:
		record1.insert(item)
	# Printing the data inserted
	cursor = record1.find()
	for record in cursor:
		print(record['ID'])
	instances = ec2.instances.filter(Filters=[])
	linux_time = datetime.fromtimestamp(int("1284101485")).strftime('%m%d%Y')
	#instances = ec2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
	for instance in instances:
		print instance.id, instance.instance_type
		#OS_Version = "OS_Version"
		for tag in instance.tags:
			if 'TTL_Shutdown_Date'in tag['Key']:
				instance.create_tags(Tags=[
				{
				"Key" : 'TTL_Shutdown_Date', 
				"Value" : '03052018'
				}])
			else:
				instance.create_tags(Tags=[
				{
				"Key" : 'TTL_Shutdown_Date', 
				"Value" : '08052017'
				}])
	print("Execution completed")
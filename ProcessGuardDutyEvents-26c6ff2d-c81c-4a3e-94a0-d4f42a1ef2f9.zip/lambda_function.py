import json,boto3

def lambda_handler(event, context):
    # TODO implement
    accountId=event['detail']["accountId"]
    region=event['detail']["region"]
    type=event['detail']["type"]
    severity=event['detail']['severity'] 
    
    if 7 >= severity <= 8.9:
        severity='High'
    elif 4 >= severity <= 6.9:
        severity='Medium'
    elif 0.1 >= severity <= 3.9:
        severity='Low'
        
    print(severity)    
    
    title=event['detail']['title']
    description=event['detail']['description']
    
    msg_subject='GuardDuty-Finding AC:ServiceOps Region:' +region+' Type:'+type+' Severity:'+severity
    Message= 'Title:'+title + ' Description: '+description
    
    '''
    print(accountId)
    print(region)
    print(type)
    print(severity)
    print(title)
    print(description)
    '''
    
    # Publish to SNS topic (created)
    snsClient=boto3.client('sns',region_name='us-east-1')
    snsResponse = snsClient.publish(TopicArn='arn:aws:sns:us-east-1:948173514100:serviceOps',Message=Message,Subject=msg_subject)
    #print (snsResponse)
    print (msg_subject + ' '+ Message)
	
    return {
        'statusCode': 200
    }

import boto3
from datetime import datetime
from botocore.exceptions import ClientError

#sts_client = boto3.client('sts')
ec2 = boto3.resource('ec2')
def lambda_handler(event, context):
    print(event)     
    print('ABC')
    eventname = event['detail']['eventName']
    principal = event['detail']['userIdentity']['principalId']
    userType = event['detail']['userIdentity']['type']
    region = event['region']
    time = event['time']
    print(time)
    print(region)
    print(eventname)
    print(principal)
    print(userType)
    
    #awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    #awsAccounts=['579292207088']
    
    """
    for accountNumber in awsAccounts:
        print(accountNumber)
        
        try:
            ec_client = boto3.client('ec2')
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )
            
            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
           
     
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
              
            
            
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            #regions = ['us-east-1']
            print(regions)
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2',aws_access_key_id = credentials['AccessKeyId'],
                #clientEC2 = boto3.resource('ec2', region_name = region)
                aws_secret_access_key = credentials['SecretAccessKey'],
                aws_session_token = credentials['SessionToken'], region_name=region)
               
            
                #snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running','stopped']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                    print(instance_tags)
                    
                
                    for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                """
    if userType == 'IAMUser':
        user = event['detail']['userIdentity']['userName']
        print(user)

    else:
        user = principal.split(':')[1]
        print('instance is created by principal') 
        
    if eventname == 'RunInstances':
        items = event['detail']['responseElements']['instancesSet']['items']
        ids = []
        for item in items:
            ids.append(item['instanceId'])
            
            base = ec2.instances.filter(InstanceIds=ids)
            print(base)
            print(ids)
            
            if ids:
                ec2.create_tags(
                    Resources=ids, 
                    Tags=[
                        {
                            'Key': 'Owner', 
                            'Value': user
                        },    
                        {
                            'Key': 'Region',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'Project',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'TTL Start Time',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'TTL Shutdown Time',
                            'Value': '19'
                            
                        },
                        {
                            'Key': 'Day',
                            'Value': ''
                                    
                        },
                        {
                            'Key': 'Archive',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'Name',
                            'Value': 'New Instance'
                            
                        },
                        {
                            'Key': 'Project Start Date',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'Project End Date',
                            'Value': ''
                            
                        },
                        {
                            'Key': 'Purpose',
                            'Value': ''
                            
                        }
                    ]
                )
                print('All tags are created successfully for new instance')
                            
                                        
                                        
                            
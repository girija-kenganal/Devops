import boto3

def lambda_handler(event, context):
    
    
    # TODO implement
    # Get the file name use it as stackname as it satisfy the unique file name req
    # print(event)
    
    print(event['Records'][0]['s3']['object']['key'])
    
    fileName = event['Records'][0]['s3']['object']['key']
    
    client = boto3.client('cloudformation')
    
    validStackName=fileName.split(".")[0].replace("_","")
    
    response = client.create_stack(
    StackName=validStackName,
    TemplateURL='https://s3.amazonaws.com/cf-templates-serviceops/'+fileName,
    Parameters=[
        {
            'ParameterKey': 'PipelineName',
            'ParameterValue':  fileName.split(".")[0],
            'UsePreviousValue': False

        },{
            'ParameterKey': 'S3Bucket',
            'ParameterValue': 'cf-templates-serviceops',
            'UsePreviousValue': False

        },{
            'ParameterKey': 'SourceS3Key',
            'ParameterValue': 'controlcenter.zip',
            'UsePreviousValue': False

        },
        {
            'ParameterKey': 'TemplateFileName',
            'ParameterValue': 'stack.yaml',
            'UsePreviousValue': False

        }, 
        {
            'ParameterKey': 'TestStackName',
            'ParameterValue': 'controlcenter-test-stack',
            'UsePreviousValue': False

        },{
            'ParameterKey': 'TestStackConfig',
            'ParameterValue': 'test-stack-configuration.json',
            'UsePreviousValue': False

        },{
            'ParameterKey': 'Email',
            'ParameterValue': 'kavashgar.manimarpan@nextlabs.com',
            'UsePreviousValue': False

        }
    ],
    DisableRollback=True,
    TimeoutInMinutes=123,
    Capabilities=[
        'CAPABILITY_IAM'
    ],
	RoleARN='arn:aws:iam::948173514100:role/sample-WordPress-pipeline-CFNRole-1IPYA3OYHEEGL',
    Tags=[
        {
            'Key': 'Owner',
            'Value': 'kavashgar.manimarpan@nextlabs.com'
        }, {
            'Key': 'TTL Shutdown Time',
            'Value': '24'
        },
         {
            'Key': 'Region',
            'Value': 'sgdc'
        },{
            'Key': 'Project',
            'Value': 'CloudAz'
        },{
            'Key': 'TTL Start Time',
            'Value': '09'
        },{
            'Key': 'Name',
            'Value': 'CloudAzSrvOpsStaging'
        }
        
        ]
    )
    
 
    
    return 'Hello from Lambda'

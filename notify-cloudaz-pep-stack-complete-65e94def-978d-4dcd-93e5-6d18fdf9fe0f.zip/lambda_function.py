import json,boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # TODO implement
    ddbClient = boto3.resource('dynamodb', region_name='us-west-2')
    table = ddbClient.Table('cloudaz-peps')
    # print(event['Records'][0]['Sns']['Message'])
    msg=event['Records'][0]['Sns']['Message']
    text = msg.splitlines()
    for line in text:
        if "StackName" in line :
            #print (line);
            stackN=line.split('=')[1]
            #print(stackN.replace("'",""))
            stackName=stackN.replace("'","")
   
    client = boto3.client('cloudformation')
    response = client.describe_stacks(
        StackName=stackName
    )
    # get CCAdministrator email from stack describe use that for dynamodb key when updating 
    # provision status
    if response['Stacks'][0]['Parameters'][27]['ParameterKey']=='CCAdministratorEmail' :
        CCAdministratorEmail = response['Stacks'][0]['Parameters'][27]['ParameterValue'] 

    #print(CCAdministratorEmail)
    
    if response['Stacks'][0]['StackStatus']!='CREATE_COMPLETE':
        # update DynamoDB table with provisionStatus
        try:
      
            responseDdb = table.update_item(
                                Key={
                                    'email': CCAdministratorEmail
                                    
                                },
                                UpdateExpression='SET provisionStatus = :val1',
                                ExpressionAttributeValues={
                                    ':val1': response['Stacks'][0]['StackStatus']
                                }
                            )
            
            print(response['Stacks'][0]['StackStatus'])
        except ClientError as e:
           print(e)
        
    elif response['Stacks'][0]['StackStatus']=='CREATE_COMPLETE':
        # update DynamoDB table with provisionStatus = CREATE_COMPLETE
        try:
      
            responseDdb = table.update_item(
                                Key={
                                    'email': CCAdministratorEmail
                                   
                                },
                                UpdateExpression='SET provisionStatus = :val1',
                                ExpressionAttributeValues={
                                    ':val1':'CREATE_COMPLETE'
                                }
                            )
            
            print('provisionStatus has been updated to CREATE_COMPLETE')
        except ClientError as e:
           print(e)

    #print(response)
    
            
    #return stackN.replace("'","")
   
    

    
    
    

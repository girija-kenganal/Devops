import json
import boto3
import pymongo
from datetime import datetime
import pprint
def lambda_handler(event, context):
	ec2 = boto3.resource('ec2', 'us-east-1')
	MONGO_HOST = "ec2-52-22-1-176.compute-1.amazonaws.com"
	MONGO_DB = "cloudaz"
	MONGO_USER = "nextlabs"
	MONGO_PASS = "123next!"
	print("Establishing connection")
	
	#client = pymongo.MongoClient('mongodb://nextlabs:123next!@10.0.160.161:27017/cloudaz')
	connection=pymongo.MongoClient("mongodb://nextlabs:123next!@10.0.160.161:27017/cloudaz")
	db=connection.cloudaz
	record1=db.instanceCollection
	cursor = record1.find()
	for record in cursor:
		print(record['instanceId'])
		print(record['details']['terminationDate'])
		linux_time = datetime.fromtimestamp(int(record['details']['terminationDate'])).strftime('%m%d%Y')
		print(linux_time)
		
		
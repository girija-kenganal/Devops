import boto3
from datetime import datetime
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
    #print(event)     
    #awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    awsAccounts=['948173514100']
    
    for accountNumber in awsAccounts:
        
        try:
            ec_client = boto3.client('ec2')
            """
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )
            
            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
           
     
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
              
            
            """
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            #regions = ['us-east-1']
            print(regions)
            
            msgString=''
            
            for region in regions:
                print(region)
                #clientEC2 = boto3.resource('ec2',aws_access_key_id = credentials['AccessKeyId'],
                clientEC2 = boto3.resource('ec2', region_name = region)
                #aws_secret_access_key = credentials['SecretAccessKey'],
                #aws_session_token = credentials['SessionToken'], region_name=region)
               
            
                #snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running','stopped']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                    print(instance_tags)
                    
                
                    for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                
                     
                    if not tagDict.get('TTL Shutdown Time'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'TTL Shutdown Time', 'Value': ''}])
                        print('TTL Shutdown Time tag is created')
                    
                    if not tagDict.get('TTL Start Time'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'TTL Start Time', 'Value': ''}])
                        print('TTL Start Time tag is created')
                        
                    if not tagDict.get('Region'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Region', 'Value': ''}])
                        print('Region tag is created')
                        
                    if not tagDict.get('Name'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Name', 'Value': ''}])
                        print('Name tag is created')
                        
                    if not tagDict.get('Owner'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Owner', 'Value': ''}])
                        print('Owner tag is created')
                        
                    if not tagDict.get('Project'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Project', 'Value': ''}])
                        print('Project tag is created')
                        
                    if not tagDict.get('Purpose'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Purpose', 'Value': ''}])
                        print('Purpose tag is created')
                        
                    if not tagDict.get('Project End Date'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Project End Date', 'Value': ''}])
                        print('Project End Date tag is created')
                        
                    if not tagDict.get('Project Start Date'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Project Start Date', 'Value': ''}])
                        print('Project Start Date tag is created')
                        
                    if not tagDict.get('Archive'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Archive', 'Value': ''}])
                        print('Archive tag is created')
                        
                    if not tagDict.get('Day'):
                        clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Day', 'Value': ''}])
                        print('Day tag is created')
                    
                    print(instance_tags)
                                            
                            
        except ClientError as e:
            print(e)         
                
    return "success"

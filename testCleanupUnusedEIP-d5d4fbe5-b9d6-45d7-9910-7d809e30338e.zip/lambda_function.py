import boto3
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')


def lambda_handler(event, context):

    '''    
    AWS ServiceOps 	#948173514100 - excluded
    Dennis Andrie	#683004025238 - cross access have
    Yann Lejas	#025378961092 
    Tapas Das	#604598747873 -  - cross access have
    NextLabsProd	#512169772597 - exclude SkyDRM Prod Account
    DevOps	#579292207088 - cross access have
    NextLabs PM	#167566316586 - cross access have
    NextLabs SaaS	#488100914863 - exclude CloudAz Prod Account
    '''
    awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    #awsAccounts=['579292207088']
    
    for accountNumber in awsAccounts:
        try:
            
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )
        
            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
                
            # Use the temporary credentials that AssumeRole returns to make a
            # connection to Amazon S3
            
            
            s3_resource = boto3.resource(
                's3',
                aws_access_key_id = credentials['AccessKeyId'],
                aws_secret_access_key = credentials['SecretAccessKey'],
                aws_session_token = credentials['SessionToken']
            )
            
                
            #print(s3_resource)
            
            # Use the Amazon S3 resource object that is now configured with the
            # credentials to access your S3 buckets.
            
            #for bucket in s3_resource.buckets.all():
                #print(bucket.name)
            
            
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
            
            
            
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
            #print(regions)
            
            msgString=''
            
            for region in regions:
     
                clientEC2 = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
                aws_secret_access_key = credentials['SecretAccessKey'],
                aws_session_token = credentials['SessionToken'], region_name=region)
                
    
                snsClient=boto3.client('sns')
                
                addresses_dict = clientEC2.describe_addresses()
            
                for eip_dict in addresses_dict['Addresses']:
                    #print(eip_dict)
                    #print(accountNumber+ " - " +region + " " + eip_dict['PublicIp'])
                    
                    
                    if 'InstanceId' not in eip_dict.keys() and 'PrivateIpAddress' not in eip_dict.keys():
         
                        msgString=msgString + " \n Released From A/C :"+ accountNumber+ " - Region - " + region + " - "+eip_dict['PublicIp']+ " \n"
                        
                        try:
                            clientEC2.release_address(AllocationId=eip_dict['AllocationId'])
  
                            print('Address released')
                        except ClientError as e:
                            print(e)

                
            if not msgString=='':
                
                snsResponse = snsClient.publish(   TopicArn='arn:aws:sns:us-east-1:948173514100:serviceOps',
                            Message=msgString,
                            Subject='Unused EIPs has been released')
                            
                print(snsResponse)  
            
            
            
        
                            
        except ClientError as e:
            print(e)         
                
    return "success"

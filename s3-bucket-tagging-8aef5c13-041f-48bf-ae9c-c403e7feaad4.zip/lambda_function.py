import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    S3 = boto3.client('s3')
    region=['us-east-1','us-west-1'] 
    
    allBuckets = S3.list_buckets()
    print(allBuckets)
    for bucket in allBuckets['Buckets']:
        try:
            Bucket_tag = S3.put_bucket_tagging(
            Bucket=bucket['Name'],
            Tagging={
                'TagSet': [
                    {
                        'Key': 'Project ',
                        'Value': 'CloudOps',
                    },
                    {
                        'Key': 'Owner ',
                        'Value': 'david.lim@nextlabs.com',
                    },
                ],
            },
            )
            print(Bucket_tag)
        except ClientError as e:
            print("Bucket: %s, unexpected error: %s" % (bucket['Name'], e))
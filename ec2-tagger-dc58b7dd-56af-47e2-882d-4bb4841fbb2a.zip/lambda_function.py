import boto3
from datetime import datetime
from botocore.exceptions import ClientError

sts_client = boto3.client('sts')

def lambda_handler(event, context):
    print(event)     
    #awsAccounts=['683004025238','025378961092','604598747873','579292207088','167566316586']
    awsAccounts=['948173514100']
    
    for accountNumber in awsAccounts:
        
        try:
            
            # Call the assume_role method of the STSConnection object and pass the role
            # ARN and a role session name.
            assumedRoleObject = sts_client.assume_role(
                RoleArn="arn:aws:iam::"+accountNumber+":role/ServiceOpsCrossAccountAccess",
                RoleSessionName="AssumeRoleSession1"
            )
            
            # From the response that contains the assumed role, get the temporary
            # credentials that can be used to make subsequent API calls
            credentials = assumedRoleObject['Credentials']
            
           
     
            ec2_client = boto3.client('ec2',aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken'])
              
            
            
            regions = [region['RegionName'] for region in ec2_client.describe_regions()['Regions']]
           
            
            msgString=''
            
            for region in regions:
                print(region)
                clientEC2 = boto3.resource('ec2',aws_access_key_id = credentials['AccessKeyId'],
                aws_secret_access_key = credentials['SecretAccessKey'],
                aws_session_token = credentials['SessionToken'], region_name=region)
               
            
                snsClient=boto3.client('sns')
                
                instances = clientEC2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running','stopped']}])
                instanceList = []
                
                for instance in instances:
                    instanceList.append(instance.id)
                    instance = clientEC2.Instance(instance.id)
                
                    instance_tags = instance.tags
                    tagDict = dict()
                
                    
                
                    if instance_tags:
                
                        for tag in instance_tags:
                            tagDict[tag['Key']] = tag['Value']
                
                        try:
                            
                            if tagDict.get('TTL Shutdown Time') and tagDict.get('TTL Shutdown Time') == 'none':
                                clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'TTL Shutdown Time', 'Value': '18'}])
    
                            if tagDict.get('Region') and tagDict.get('Region') == 'none':
                                clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': 'Region', 'Value': 'sgdc'}])
                    
                            print(instance_tags)
                    
                            availTagList = []
                            requiredTagList = ["Name", "Owner", "Project","Purpose", "Region", "TTL Start Time", "TTL Shutdown Time", "Project End Date", "Project Start Date", "Archive", "Day"]
                            
                            for instance_tag in instance_tags:
                                tag_key = instance_tag['Key']
                                tag_value = instance_tag['Value']
                    
                                availTagList.append(tag_key)
                    
                            tagNeeds = list(set(requiredTagList) - set(availTagList))
                    
                            for key in tagNeeds:
                                print("Tag Key : " + key)
                                
                                value='none'
                                
                                if key =='TTL Shutdown Time' :
                                    value='18'
                                
                                if key =='Region':
                                    value='sgdc'
                                    
                                clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': key, 'Value': value}])
                                                
                        except ClientError as e:
                            print(e)
                    
                    else:
                        requiredTagList = ["Name", "Owner","Project", "Purpose", "Region", "TTL Start Time", "TTL Shutdown Time","TTL Shutdown Date"]
                
                        for key in requiredTagList:
                            
                            print("Tag Key : " + key)
                            
                            value='none'
                            
                            if key =='TTL Shutdown Time' :
                                value='18'
                            
                            if key =='Region':
                                value='sgdc'
                            
                            clientEC2.create_tags(Resources=[instance.id], Tags=[{'Key': key, 'Value': value}])
                
        print(accountNumber + " - " + region +  " Tagging Operation completed")
    
                '''  
                if not msgString=='':
                    snsResponse = snsClient.publish(   TopicArn='arn:aws:sns:us-east-1:948173514100:serviceOps',
                                Message=msgString,
                                Subject='Shutdowned EC2 instances without valid Owner tag across all Account')
                                
                    print(snsResponse)  
                
                '''
            
        
                            
        except ClientError as e:
            print(e)         
                
    return "success"
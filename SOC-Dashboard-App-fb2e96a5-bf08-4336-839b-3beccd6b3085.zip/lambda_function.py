import json
import boto3
import pprint
import time
import requests
import logging
import os
import json,boto3,sys ,datetime ,time
import hashlib,hmac,random
import smtplib
import re

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

AutoScalingGroupName = 'ASG-SOC-Dashboard-App'
LaunchConfigurationName = 'SOC-Dashboard-APP-V2'
def lambda_handler(event, context):
    
    # get autoscaling client
    client = boto3.client('autoscaling')
    
    # scaled-up ASG with new instance 
    asg_scaleup_response = client.update_auto_scaling_group(
          AutoScalingGroupName = AutoScalingGroupName,
          LaunchConfigurationName = LaunchConfigurationName,
          MaxSize=2,
          MinSize=2,
          DesiredCapacity=2,
          DefaultCooldown=300,
          HealthCheckType='EC2',
          HealthCheckGracePeriod=300,
          AvailabilityZones=[
             'us-east-1a',
             'us-east-1b'
          ],
    )
    # suspend execution for 100 seconds using sleep() method 
    time.sleep( 100 )
    asg_response = client.describe_auto_scaling_groups(
          AutoScalingGroupNames=[
            AutoScalingGroupName,
          ],
    )['AutoScalingGroups'][0]
    pprint.pprint(asg_response)
    #pprint.pprint(asg_response['Instances'][1]['HealthStatus'])
    pprint.pprint(asg_response['Instances'][1]['LifecycleState'])
    
    
    # scaled down ASG old instance if new instance is InService
    if asg_response['Instances'][1]['LifecycleState'] == 'InService':
       asg_scaledown_response = client.update_auto_scaling_group(
          AutoScalingGroupName = AutoScalingGroupName,
          LaunchConfigurationName = LaunchConfigurationName,
          MaxSize=1,
          MinSize=1,
          DesiredCapacity=1,
          DefaultCooldown=300,
          HealthCheckType='EC2',
          HealthCheckGracePeriod=300,
          AvailabilityZones=[
             'us-east-1a',
             'us-east-1b'
          ],
      )
    else:
      print("New instance of ASG is unhealthy ")
    time.sleep( 60 )  
    try:
        url='https://soc.nextlabs.com'
        response = requests.get(url)
        # If the response was successful, no Exception will be raised
        response.raise_for_status()
    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')  # Python 3.6
    except Exception as err:
        print(f'Other error occurred: {err}')  # Python 3.6
        #postFailedMessageToTeams()
    else:
        print('Deployment is successfull')
        #postSuccessMessageToTeams()   

    